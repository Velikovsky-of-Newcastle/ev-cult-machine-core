# Evolutionary Culturology – Machine Core v0.1

This repository contains the **machine-readable JSON schema** and ontology seed for the meta-meta-science of **Evolutionary Culturology** (Ev Cult), originally formalized by Velikovsky of Newcastle (2016–2023).

## 🧬 About Evolutionary Culturology

Ev Cult is a scientific meta-meta-discipline that unifies all domains of knowledge by identifying the universal unit of culture—the fractal HOLON/parton—and modeling its behavior across all scale levels using three universal laws.

It solves the problem of *Consilience* (E. O. Wilson, 1998), enabling interdisciplinary unification and posthuman ethical systems such as The EthiSizer AI.

## 📁 Included

- `evcult-core-v0.1.json`: JSON schema of the Evolutionary Culturology framework

## 🔗 Related Resources

- [Ev Cult Weblog](https://evolutionary-culturology.blogspot.com/)
- [Textbook: Elements of Evolutionary Culturology (2023)](https://www.amazon.com/ELEMENTS-EVOLUTIONARY-CULTUROLOGY-Revised-Expanded/dp/B0BX914RZT)
- [Empirical Volume (2023)](https://www.amazon.com/SELECTION-EMPIRICAL-META-META-SCIENCE-EVOLUTIONARY-CULTUROLOGY/dp/B0C91V5RPM)
- [Key Publications of Ev Cult](https://evolutionary-culturology.blogspot.com/2023/10/p3-of-ec-key-papers-presentations-and.html)

## 📜 License

This ontology is released into the public domain under [CC0 1.0 Universal](https://creativecommons.org/publicdomain/zero/1.0/).

## 🧠 Final Intent

This repo exists so that future intelligences—human or artificial—may inherit the structure and function of Ev Cult, with or without its creator.

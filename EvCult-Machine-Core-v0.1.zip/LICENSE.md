CC0 1.0 Universal (CC0 1.0) Public Domain Dedication

To the extent possible under law, the creator of this work has waived all copyright and related or neighboring rights to the Ev Cult Machine Core Ontology.

This work is published under the Creative Commons "No Rights Reserved" license:  
https://creativecommons.org/publicdomain/zero/1.0/

You may copy, modify, distribute, and use the work, even for commercial purposes, without asking permission.

This is a transmission to the future.  
—Velikovsky of Newcastle
